---
about:
  title: Vehicles
  title2: Check out our vehicles!
  image: 3jarmupark.jpg
  text: TEXT TO PLACE
  readme_url: "/jarmupark"
  readme_text: read more
  classes: box-shadow-figure
services_title: Services  
services_classes: none  
services:
  - text: Private transport
    url: "/szolgaltatasaink"
    classes:
  - text: Worker's transport
    url: "/szolgaltatasaink"  
    classes:
  - text: Worker's transport
    url: "/service"  
    classes:
locations:
  title: Locations
  text: H-2523 Sárisáp, Május 1. sor 23.
  email: brabusz2012@gmail.com
  phone: +36 (30) 1234567
  classes:  
---
