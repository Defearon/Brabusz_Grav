---
about:
  title: Járműpark
  title2: Tekintse meg járműveinket!
  image: 3jarmupark.jpg
  text: SZÖVEG HELYE
  readme_url: "/jarmupark"
  readme_text: tovább...
  classes: box-shadow-figure
services_title: Szolgáltatások
services_classes: none  
services:
  - text: Személyszállítás (különjárat)
    url: "/szolgaltatasaink"
    classes:
  - text: Dolgozószállítás
    url: "/szolgaltatasaink"
    classes:
  - text: Szervíz
    url: "/szolgaltatasaink"
    classes:
locations:
  title: Címünk
  text: H-2523 Sárisáp, Május 1. sor 23.
  email: brabusz2012@gmail.com
  phone: +36 (30) 1234567
  classes:

---
